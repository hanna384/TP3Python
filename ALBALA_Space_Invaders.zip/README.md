# TP3Python
# le 5 janvier 2021
# programme écrit par Hanna Albala
# NB: étant absente au premier TP, j'ai travaillée seule et pas en binome, le jeu n'est pas complet mais bien avancé
# lien gitHub    https://github.com/hanna384/TP3Python.git